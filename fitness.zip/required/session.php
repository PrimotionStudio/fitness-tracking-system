<?php
session_start();

require_once "func/misc.php";
