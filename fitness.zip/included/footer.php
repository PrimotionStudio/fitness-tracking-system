<footer class="footer pt-3  ">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-12 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-end">
                    © <script>
                        document.write(new Date().getFullYear())
                    </script>,
                    made with &hearts; by
                    <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Creative Tim</a> &
                    <a href="https://primotionstudio.github.io" class="font-weight-bold" target="_blank">The Primotion Studio</a>
                    for a better web.
                </div>
            </div>
        </div>
    </div>
</footer>